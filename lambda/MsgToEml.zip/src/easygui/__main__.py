from .boxes.demo import easygui_demo
easygui_demo()